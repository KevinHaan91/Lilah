package com.example.aiassistant

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class AIAssistantApplication : Application()

